document.addEventListener("DOMContentLoaded", () => {
    console.log("Portfolio website loaded successfully!");

    // Smooth Scroll for Internal Links
    document.querySelectorAll("a[href^='#']").forEach(anchor => {
        anchor.addEventListener("click", function(event) {
            event.preventDefault();
            document.querySelector(this.getAttribute("href")).scrollIntoView({
                behavior: "smooth"
            });
        });
    });

    // Highlight Active Section on Scroll
    const sections = document.querySelectorAll("section");
    window.addEventListener("scroll", () => {
        let scrollPosition = window.scrollY + 100;
        sections.forEach(section => {
            if (scrollPosition >= section.offsetTop && scrollPosition < section.offsetTop + section.offsetHeight) {
                document.querySelectorAll("nav a").forEach(nav => {
                    nav.classList.remove("active");
                });
                let activeLink = document.querySelector(`nav a[href='#${section.id}']`);
                if (activeLink) activeLink.classList.add("active");
            }
        });
    });

    // ChatGPT Button Hover Effect
    document.querySelectorAll(".chatgpt-button").forEach(button => {
        button.addEventListener("mouseover", () => {
            button.style.transform = "scale(1.1)";
            button.style.transition = "0.3s";
        });
        button.addEventListener("mouseleave", () => {
            button.style.transform = "scale(1)";
        });
    });

// Toggle Sections on Click with Smooth Slide Animation
document.querySelectorAll("section h2").forEach(title => {
    let content = title.nextElementSibling;
    content.style.maxHeight = "0px"; // Initially collapsed
    content.style.overflow = "hidden";
    content.style.transition = "max-height 0.5s ease-out, opacity 0.5s ease-in-out";
    content.style.opacity = "0"; // Hide initially
    title.style.cursor = "pointer";

    title.addEventListener("click", () => {
        if (content.style.maxHeight === "0px") {
            content.style.maxHeight = content.scrollHeight + "px";
            content.style.opacity = "1";
        } else {
            content.style.maxHeight = "0px";
            content.style.opacity = "0";
        }
    });
});


    // Toggle Chat Links in Featured Project Section
    const featuredTitle = document.querySelector("#featured h2");
    const chatLinks = document.querySelectorAll("#featured .chatgpt-button");
    chatLinks.forEach(link => link.style.display = "none"); // Hide initially

    featuredTitle.style.cursor = "pointer";
    featuredTitle.addEventListener("click", () => {
        chatLinks.forEach(link => {
            link.style.display = link.style.display === "none" ? "inline-block" : "none";
        });
    });
});

// Smooth fade-in animation on scroll
document.addEventListener("DOMContentLoaded", () => {
    const sections = document.querySelectorAll("section");
    const fadeInObserver = new IntersectionObserver((entries) => {
        entries.forEach((entry) => {
            if (entry.isIntersecting) {
                entry.target.classList.add("fade-in-visible");
            }
        });
    }, { threshold: 0.2 });

    sections.forEach((section) => {
        section.classList.add("fade-in");
        fadeInObserver.observe(section);
    });
});

// Lightbox Effect for Logo Showcase
document.querySelectorAll(".logo-item img").forEach(img => {
    img.addEventListener("click", function() {
        const lightbox = document.createElement("div");
        lightbox.classList.add("lightbox");
        lightbox.innerHTML = `<div class="lightbox-content">
            <span class="close-lightbox">&times;</span>
            <img src="${this.src}" alt="${this.alt}">
            <p>${this.alt}</p>
        </div>`;

        document.body.appendChild(lightbox);

        document.querySelector(".close-lightbox").addEventListener("click", () => {
            lightbox.remove();
        });
    });
});

